# تطبيق عمار للتمارين
مشروع Android Studio يغلّف ملف `index.html` الحالي كتطبيق Android أصلي باستخدام WebView.

## البناء
1. افتح المجلد في Android Studio.
2. انتظر Gradle Sync.
3. Build > Build APK(s).
4. ملف APK سيظهر داخل `app/build/outputs/apk/`.

التطبيق يستخدم JavaScript وDOM Storage حتى تستمر وظائف localStorage الموجودة في الموقع.
